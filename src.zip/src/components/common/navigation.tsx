"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Map, FileText, Target, Gift, BarChart3, Bell, Settings, LogOut, Store } from "lucide-react"
import { Button } from "~/components/shadcn/ui/button"
import { Avatar, AvatarFallback } from "~/components/shadcn/ui/avatar"
import { Badge } from "~/components/shadcn/ui/badge"
import Image from "next/image"
import { signOut, useSession } from "next-auth/react"

const navItems = [
    { href: "/map", label: "Map", icon: Map },
    { href: "stores", label: "Stores", icon: Store },
    { href: "/posts", label: "Posts", icon: FileText },
    { href: "/bounties", label: "Bounties", icon: Target, badge: "8" },
    { href: "/gifts", label: "Gifts", icon: Gift },
    { href: "/report", label: "Report & Analytics", icon: BarChart3 },
]

export function Navigation() {
    const pathname = usePathname()
    const session = useSession()
    return (
        <div className="w-16 hover:w-64 transition-all duration-300 bg-primary/10   border-r border-gray-100 h-screen flex flex-col group shadow-sm z-30">
            {/* Logo */}
            <div className="p-4 border-b border-gray-100"
                onClick={() => window.location.href = "/map"}
            >
                <div className="flex items-center gap-3">
                    <div className="w-8 h-8  rounded-lg flex items-center justify-center flex-shrink-0"

                    >
                        <Image
                            src="/images/loading.png"
                            alt="Logo"
                            width={100}
                            height={100}
                            className="h-full w-full object-cover "
                        />
                    </div>
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 overflow-hidden">
                        <h1 className="text-lg font-semibold text-gray-900 whitespace-nowrap">Wadzzo</h1>
                    </div>
                </div>
            </div>

            {/* Navigation Links */}
            <nav className="flex-1 p-2">
                <div className="space-y-1">
                    {navItems.map((item) => {
                        const isActive = pathname === item.href
                        return (
                            <Link key={item.href} href={item.href}>
                                <div
                                    className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 relative ${isActive ? "bg-primary text-white" : "hover:bg-secondary"
                                        }`}
                                >
                                    <item.icon className="w-5 h-5 flex-shrink-0" />
                                    <span className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap">
                                        {item.label}
                                    </span>

                                    {isActive && (
                                        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-accent rounded-r"></div>
                                    )}
                                </div>
                            </Link>
                        )
                    })}
                </div>
            </nav>

            {/* User Profile */}
            <div className="p-2 border-t border-gray-100">
                <div className="flex items-center gap-3 px-3 py-2.5 w-full">

                    <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 overflow-hidden w-full">
                        {
                            session.status === 'authenticated' && (
                                <LogOutButon />
                            )
                        }
                    </div>
                </div>

                <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 space-y-1 mt-2">
                    <Button variant="ghost" size="sm" className="w-full justify-start text-gray-600">
                        <Settings className="w-4 h-4 mr-2" />
                        Settings
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start text-gray-600">
                        <Bell className="w-4 h-4 mr-2" />
                        Notifications
                    </Button>
                </div>
            </div>
        </div>
    )
}
function LogOutButon() {
    async function disconnectWallet() {
        await signOut({
            redirect: false,
        });
    }
    return (
        <Button className="flex  p-3 shadow-sm  w-full" onClick={disconnectWallet}>

            <LogOut />Logout
        </Button>
    );
}