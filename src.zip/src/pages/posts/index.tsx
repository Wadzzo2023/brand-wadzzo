import { ImageIcon, Plus } from "lucide-react"
import { useSession } from "next-auth/react"
import React from "react"
import { Button } from "~/components/shadcn/ui/button"
import { api } from "~/utils/api"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "~/components/shadcn/ui/card"
import { Skeleton } from "~/components/shadcn/ui/skeleton"
import PostCard from "~/components/post/post-card"
import { CreatePostModal } from "~/components/modals/create-post-modal"

const CreatorPost = () => {
    const session = useSession()
    const [isPostModalOpen, setIsPostModalOpen] = React.useState(false)
    const allCreatedPost = api.fan.post.getPosts.useInfiniteQuery(
        {
            pubkey: session.data?.user.id ?? "",
            limit: 10,
        },
        {
            getNextPageParam: (lastPage) => lastPage.nextCursor,

        },
    )
    return (
        <>
            <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold">Your Posts</h2>
            </div>

            <div className="space-y-6 ">
                {allCreatedPost.isLoading && (
                    <div className="space-y-4 ">
                        {[1, 2, 3].map((i) => (
                            <Card key={i} className="overflow-hidden">
                                <CardHeader>
                                    <Skeleton className="h-6 w-1/3 mb-2" />
                                    <Skeleton className="h-4 w-1/4" />
                                </CardHeader>
                                <CardContent>
                                    <Skeleton className="h-4 w-full mb-2" />
                                    <Skeleton className="h-4 w-full mb-2" />
                                    <Skeleton className="h-4 w-2/3 mb-4" />
                                    <Skeleton className="h-48 w-full rounded-md mb-4" />
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                )}

                {allCreatedPost.data?.pages.map((page, i) => (
                    <React.Fragment key={i}>
                        {page.posts.map((post) => (

                            <PostCard
                                key={post.id}
                                post={post}
                                creator={post.creator}
                                likeCount={post._count.likes}
                                commentCount={post._count.comments}
                                locked={post.subscription ? true : false}
                                show={true}
                                media={post.medias}
                            />

                        ))}
                    </React.Fragment>
                ))}

                {allCreatedPost.hasNextPage && (
                    <Button
                        variant="outline"
                        className="w-full"
                        onClick={() => allCreatedPost.fetchNextPage()}
                        disabled={allCreatedPost.isFetchingNextPage}
                    >
                        {allCreatedPost.isFetchingNextPage ? "Loading more..." : "Load More Posts"}
                    </Button>
                )}

                {allCreatedPost.data?.pages[0]?.posts.length === 0 && (
                    <div className="text-center py-12 bg-muted/30 rounded-lg">
                        <ImageIcon className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                        <h3 className="text-lg font-medium mb-2">No Posts Yet</h3>
                        <p className="text-muted-foreground mb-4">Start creating content for your followers</p>
                        <Button onClick={() => setIsPostModalOpen(true)}>
                            <Plus className="h-4 w-4 mr-2" />
                            Create Your First Post
                        </Button>
                    </div>
                )}
            </div>
            {isPostModalOpen && (
                <CreatePostModal
                    isOpen={isPostModalOpen}
                    setIsOpen={setIsPostModalOpen}

                />
            )}
        </>
    )
}
export default CreatorPost;