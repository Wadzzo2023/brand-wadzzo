"use client";
import clsx from "clsx";
import { useSession } from "next-auth/react";
import dynamic from "next/dynamic";
import { useRouter } from "next/router";
import React from "react";
import { ConnectWalletButton } from "package/connect_wallet";
// import Header from "./header";
// import RightDialog from "./right_dialog";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from "~/components/shadcn/ui/card";
import { Navigation } from "../common/navigation";




export default function RootLayout({
    children,
    className,
}: {
    children: React.ReactNode;
    className?: string;
}) {

    const router = useRouter();

    const session = useSession();


    return (
        <>

            <div className="flex h-screen ">
                <Navigation />
                <main className="flex-1 overflow-auto">
                    {
                        session.status === "unauthenticated" ? (
                            <div className="flex items-center justify-center h-full">
                                <Card className="w-96">
                                    <CardHeader>
                                        <CardTitle>Connect Wallet</CardTitle>
                                        <CardDescription>
                                            Please connect your wallet to continue.
                                        </CardDescription>
                                    </CardHeader>
                                    <CardContent className="flex justify-center">
                                        <ConnectWalletButton />
                                    </CardContent>
                                </Card>
                            </div>
                        ) : (
                            children
                        )}


                </main>
            </div>
        </>
    );
}
